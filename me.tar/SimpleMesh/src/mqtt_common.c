// mqtt_common.c
// 预留通用工具函数实现 